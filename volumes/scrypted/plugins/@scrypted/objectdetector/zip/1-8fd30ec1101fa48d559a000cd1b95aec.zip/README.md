# Video Analysis Plugin for Scrypted

This plugin is used by motion and detection plugins such as OpenCV, PAM Diff, and Object Detection.

Motion Detection should only be used if your camera does not have a plugin and does not provide motion
events via email or webhooks.

The Object Detection Plugin should only be used if you are a Scrypted NVR user. It will provide no
benefits to HomeKit, which does its own detection processing.