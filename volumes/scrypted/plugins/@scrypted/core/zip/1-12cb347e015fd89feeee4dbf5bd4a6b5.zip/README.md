# Scrypted Core Plugin

The Core Plugin provides the UI, Automations, Device Groups, and other core functionality within Scrypted.
