# Motion Detection Plugin for Scrypted

The PAM Diff Motion Detection Plugin adds motion detection to any camera. This can also be used with cameras with built in motion detection.

Motion Detection should only be used if your camera does not have a plugin and does not provide motion
events via email or webhooks.


## Setup

1. Enable the integration on a camera.
2. Configure the motion percent and difference to change the sensitivity.
