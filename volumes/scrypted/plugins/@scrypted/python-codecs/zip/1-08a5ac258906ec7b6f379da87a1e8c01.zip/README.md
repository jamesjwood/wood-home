# Python Codecs for Scrypted

Adds encoding and decoding capabilites to Scrypted via Gstreamer and Libav.
